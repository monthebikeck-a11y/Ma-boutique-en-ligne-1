import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import crypto from "crypto";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
app.use(cors());
app.use(express.json({ limit: "100kb" }));

const PORT = Number(process.env.PORT || 3000);
const BASE_URL = (process.env.PUBLIC_BASE_URL || `http://localhost:${PORT}`).replace(/\/$/, "");
const CINETPAY_API = "https://api-checkout.cinetpay.com/v2/payment";
const CINETPAY_CHECK = "https://api-checkout.cinetpay.com/v2/payment/check";

const PRODUCTS = {
  1: { name: "Produit Premium", price: 15000 },
  2: { name: "Pack Essentiel", price: 25000 },
  3: { name: "Collection Classic", price: 30000 },
  4: { name: "Accessoire Plus", price: 10000 },
  5: { name: "Pack Découverte", price: 20000 },
  6: { name: "Édition Spéciale", price: 45000 }
};

const DATA_DIR = path.join(__dirname, "data");
const ORDERS_FILE = path.join(DATA_DIR, "orders.json");
fs.mkdirSync(DATA_DIR, { recursive: true });
if (!fs.existsSync(ORDERS_FILE)) fs.writeFileSync(ORDERS_FILE, "[]", "utf8");

function readOrders() {
  try { return JSON.parse(fs.readFileSync(ORDERS_FILE, "utf8")); }
  catch { return []; }
}
function writeOrders(orders) {
  fs.writeFileSync(ORDERS_FILE, JSON.stringify(orders, null, 2), "utf8");
}
function createId() {
  return "CMD-" + Date.now() + "-" + crypto.randomBytes(3).toString("hex");
}
function cleanText(value, max = 100) {
  return String(value ?? "").trim().replace(/[<>]/g, "").slice(0, max);
}
function splitName(fullName) {
  const parts = cleanText(fullName, 120).split(/\s+/).filter(Boolean);
  return {
    first: parts[0] || "Client",
    last: parts.slice(1).join(" ") || "Client"
  };
}

function calculateOrder(items) {
  if (!Array.isArray(items) || items.length < 1 || items.length > 50) {
    throw new Error("Panier invalide");
  }

  let total = 0;
  const normalized = [];

  for (const item of items) {
    const id = Number(item.productId);
    const qty = Number(item.quantity);
    const product = PRODUCTS[id];

    if (!product || !Number.isInteger(qty) || qty < 1 || qty > 99) {
      throw new Error("Produit ou quantité invalide");
    }

    const subtotal = product.price * qty;
    total += subtotal;
    normalized.push({
      productId: id,
      name: product.name,
      quantity: qty,
      unitPrice: product.price,
      subtotal
    });
  }

  // CinetPay demande un montant entier et sa documentation indique
  // que le montant doit être un multiple de 5.
  if (total < 100 || total % 5 !== 0) {
    throw new Error("Montant invalide pour CinetPay");
  }

  return { items: normalized, total };
}

async function cinetpayPost(url, payload) {
  const response = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload)
  });

  const text = await response.text();
  let data;
  try { data = JSON.parse(text); }
  catch { throw new Error("Réponse CinetPay invalide"); }

  if (!response.ok) {
    throw new Error(data.message || `CinetPay HTTP ${response.status}`);
  }
  return data;
}

app.get("/api/health", (_req, res) => {
  res.json({
    ok: true,
    cinetpayConfigured: Boolean(process.env.CINETPAY_APIKEY && process.env.CINETPAY_SITE_ID),
    cinetpayEnabled: process.env.CINETPAY_ENABLED === "true"
  });
});

app.post("/api/create-payment", async (req, res) => {
  try {
    if (process.env.CINETPAY_ENABLED !== "true") {
      return res.status(503).json({
        message: "CinetPay n'est pas encore activé. Configure le fichier .env."
      });
    }

    const { customer, items } = req.body || {};
    const { items: normalizedItems, total } = calculateOrder(items);

    const email = cleanText(customer?.email, 160);
    const phone = cleanText(customer?.phone, 40);
    const fullName = cleanText(customer?.name, 120);

    if (!fullName || !email || !phone || !email.includes("@")) {
      return res.status(400).json({ message: "Informations client invalides" });
    }

    const { first, last } = splitName(fullName);
    const transactionId = createId();

    const order = {
      transactionId,
      status: "PENDING",
      createdAt: new Date().toISOString(),
      customer: {
        name: fullName,
        email,
        phone,
        country: cleanText(customer?.country, 10)
      },
      items: normalizedItems,
      total,
      currency: "XAF"
    };

    // Sauvegarde AVANT l'affichage du guichet de paiement.
    const orders = readOrders();
    orders.push(order);
    writeOrders(orders);

    const payload = {
      apikey: process.env.CINETPAY_APIKEY,
      site_id: process.env.CINETPAY_SITE_ID,
      transaction_id: transactionId,
      amount: total,
      currency: "XAF",
      description: `Commande ${transactionId}`,
      customer_name: last,
      customer_surname: first,
      customer_email: email,
      customer_phone_number: phone,
      notify_url: `${BASE_URL}/api/cinetpay/notify`,
      return_url: `${BASE_URL}/payment-return`,
      channels: "ALL",
      lang: "FR",
      metadata: transactionId,
      invoice_data: {
        "Commande": transactionId,
        "Client": fullName,
        "Articles": String(normalizedItems.reduce((n, x) => n + x.quantity, 0))
      }
    };

    const result = await cinetpayPost(CINETPAY_API, payload);

    if (result.code !== "201" || !result.data?.payment_url) {
      throw new Error(result.message || "CinetPay n'a pas créé le paiement");
    }

    const updated = readOrders().map(o =>
      o.transactionId === transactionId
        ? { ...o, paymentToken: result.data.payment_token }
        : o
    );
    writeOrders(updated);

    res.json({
      orderId: transactionId,
      payment_url: result.data.payment_url
    });
  } catch (error) {
    console.error(error);
    res.status(400).json({ message: error.message || "Impossible de créer le paiement" });
  }
});

app.all("/api/cinetpay/notify", async (req, res) => {
  // CinetPay peut appeler cette URL plusieurs fois.
  // On répond rapidement et on vérifie le statut côté serveur.
  try {
    const body = req.body || {};
    const transactionId = cleanText(body.cpm_trans_id || body.transaction_id, 120);
    const siteId = cleanText(body.cpm_site_id, 50);

    if (!transactionId || (siteId && siteId !== String(process.env.CINETPAY_SITE_ID))) {
      return res.sendStatus(400);
    }

    const result = await cinetpayPost(CINETPAY_CHECK, {
      apikey: process.env.CINETPAY_APIKEY,
      site_id: process.env.CINETPAY_SITE_ID,
      transaction_id: transactionId
    });

    const transaction = result.data || result.transaction || {};
    const status = String(
      transaction.status ||
      transaction.payment_status ||
      result.status ||
      ""
    ).toUpperCase();

    const orders = readOrders();
    const index = orders.findIndex(o => o.transactionId === transactionId);

    if (index >= 0) {
      orders[index].lastCinetPayResponse = result;
      orders[index].updatedAt = new Date().toISOString();

      if (status === "ACCEPTED" || status === "SUCCESS" || result.code === "00") {
        orders[index].status = "PAID";
      } else if (["REFUSED", "FAILED", "CANCELLED"].includes(status)) {
        orders[index].status = "FAILED";
      } else {
        orders[index].status = "PENDING";
      }

      writeOrders(orders);
    }

    return res.sendStatus(200);
  } catch (error) {
    console.error("CinetPay notification:", error);
    // CinetPay attend une URL accessible. Le statut sera revérifié lors
    // d'une prochaine notification ou manuellement.
    return res.sendStatus(200);
  }
});

app.get("/payment-return", (req, res) => {
  res.send(`<!doctype html><html lang="fr"><meta charset="utf-8">
<title>Commande</title><meta name="viewport" content="width=device-width,initial-scale=1">
<style>body{font-family:Arial;max-width:650px;margin:70px auto;padding:20px;text-align:center}
a{display:inline-block;background:#111;color:#fff;padding:12px 18px;border-radius:8px;text-decoration:none}</style>
<h1>Merci pour votre commande</h1>
<p>Votre paiement est en cours de vérification.</p>
<p>La confirmation définitive est faite côté serveur après notification de CinetPay.</p>
<a href="/">Retour à la boutique</a></html>`);
});

app.listen(PORT, () => {
  console.log(`Backend boutique lancé sur http://localhost:${PORT}`);
});
